import Link from 'next/link'
import { useSelector } from 'react-redux'

export default function Layout({ children }) {
  const cart = useSelector(s => s.cart)
  return (
    <div>
      <nav className="bg-white shadow">
        <div className="container flex items-center justify-between py-4">
          <Link href="/"><a className="font-bold text-xl">E-Shop</a></Link>
          <div className="space-x-4">
            <Link href="/cart"><a>Cart ({cart.items.length})</a></Link>
            <Link href="/login"><a>Login/Register</a></Link>
            <Link href="/admin/dashboard"><a>Admin</a></Link>
          </div>
        </div>
      </nav>
      <main className="container py-6">{children}</main>
    </div>
  )
}
