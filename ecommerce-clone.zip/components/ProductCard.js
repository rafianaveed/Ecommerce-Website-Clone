import Link from 'next/link'

export default function ProductCard({ p, onAdd }) {
  return (
    <div className="border rounded p-4 bg-white">
      <h3 className="font-semibold">{p.name}</h3>
      <p className="text-sm my-2">{p.description}</p>
      <div className="flex items-center justify-between">
        <div>
          <div className="font-bold">${p.price}</div>
          <div className="text-xs">Stock: {p.stock}</div>
        </div>
        <div className="space-x-2">
          <Link href={'/product/' + p.id}><a className="text-sm underline">View</a></Link>
          <button onClick={() => onAdd(p)} className="px-3 py-1 bg-blue-600 text-white rounded">Add</button>
        </div>
      </div>
    </div>
  )
}
