import jwt from 'jsonwebtoken'
import cookie from 'cookie'

const SECRET = process.env.JWT_SECRET || 'devsecret'

export function sign(user) {
  return jwt.sign(user, SECRET, { expiresIn: '7d' })
}

export function verifyToken(req) {
  const cookies = req.headers.cookie ? cookie.parse(req.headers.cookie || '') : {}
  const token = cookies.token
  if (!token) return null
  try {
    const decoded = jwt.verify(token, SECRET)
    return decoded
  } catch (e) {
    return null
  }
}
