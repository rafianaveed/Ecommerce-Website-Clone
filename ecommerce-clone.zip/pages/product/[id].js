import axios from 'axios'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import Layout from '../../components/Layout'
import { useDispatch } from 'react-redux'
import { addItem } from '../../store/cartSlice'

export default function ProductPage() {
  const router = useRouter()
  const { id } = router.query
  const [product, setProduct] = useState(null)
  const dispatch = useDispatch()

  useEffect(() => {
    if (!id) return
    axios.get('/api/products').then(r => {
      const p = r.data.products.find(x => x.id === id)
      setProduct(p)
    })
  }, [id])

  if (!product) return <Layout><div>Loading...</div></Layout>

  return (
    <Layout>
      <h1 className="text-2xl font-bold">{product.name}</h1>
      <p className="my-2">{product.description}</p>
      <div className="my-4">
        <div className="font-bold">${product.price}</div>
        <div>Stock: {product.stock}</div>
      </div>
      <button className="px-4 py-2 bg-green-600 text-white rounded" onClick={() => dispatch(addItem({ id: product.id, name: product.name, price: product.price }))}>
        Add to Cart
      </button>
    </Layout>
  )
}
