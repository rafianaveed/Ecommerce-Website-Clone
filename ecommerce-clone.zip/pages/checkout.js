import { useSelector } from 'react-redux'
import Layout from '../components/Layout'
import axios from 'axios'
import { useState } from 'react'
import Router from 'next/router'

export default function Checkout() {
  const cart = useSelector(s => s.cart)
  const [loading, setLoading] = useState(false)
  const total = cart.items.reduce((s,i)=>s+i.price,0)

  async function handleMockPay() {
    setLoading(true)
    const res = await axios.post('/api/orders', { items: cart.items, total })
    // In a real app you'd redirect to Stripe/PayPal; here we just simulate success
    Router.push('/order/' + res.data.order.id)
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Checkout (Demo)</h1>
      <div className="bg-white p-4 border rounded">
        <div>Items: {cart.items.length}</div>
        <div className="font-bold">Total: ${total.toFixed(2)}</div>
        <p className="text-sm text-gray-600 mt-2">This demo uses a mock payment flow. To integrate Stripe, set STRIPE_SECRET_KEY in your environment and replace the mock flow with Stripe Checkout (instructions in README).</p>
        <button onClick={handleMockPay} disabled={loading} className="mt-4 px-4 py-2 bg-green-600 text-white rounded">
          {loading ? 'Processing...' : 'Pay (Mock)'}
        </button>
      </div>
    </Layout>
  )
}
