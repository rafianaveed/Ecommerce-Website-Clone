import Layout from '../components/Layout'
import { useSelector, useDispatch } from 'react-redux'
import { removeItem, clearCart } from '../store/cartSlice'
import Link from 'next/link'

export default function CartPage() {
  const cart = useSelector(s => s.cart)
  const dispatch = useDispatch()
  const total = cart.items.reduce((s,i)=>s+i.price,0)

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Your Cart</h1>
      {cart.items.length === 0 && <div>No items. <Link href="/"><a className="underline">Shop now</a></Link></div>}
      <div className="space-y-2">
        {cart.items.map((it, idx) => (
          <div key={idx} className="p-3 bg-white border rounded flex justify-between">
            <div>
              <div className="font-semibold">{it.name}</div>
              <div className="text-sm">${it.price}</div>
            </div>
            <div className="space-x-2">
              <button onClick={() => dispatch(removeItem(it.id))} className="px-2 py-1 border rounded">Remove</button>
            </div>
          </div>
        ))}
      </div>

      {cart.items.length > 0 && (
        <div className="mt-4">
          <div className="font-bold">Total: ${total.toFixed(2)}</div>
          <Link href="/checkout"><a className="mt-2 inline-block px-4 py-2 bg-blue-600 text-white rounded">Proceed to Checkout</a></Link>
          <button onClick={() => dispatch(clearCart())} className="ml-2 px-3 py-1 border rounded">Clear</button>
        </div>
      )}
    </Layout>
  )
}
