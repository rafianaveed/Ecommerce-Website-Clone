import { readDb, writeDb } from '../../utils/db'
import { v4 as uuidv4 } from 'uuid'
import { verifyToken } from '../../utils/auth'

export default function handler(req, res) {
  const db = readDb()
  // GET: list or single
  if (req.method === 'GET') {
    const { id } = req.query
    if (id) {
      const order = db.orders.find(o => o.id === id)
      return res.status(200).json({ order })
    }
    return res.status(200).json({ orders: db.orders })
  }

  // POST: create order or advance
  if (req.method === 'POST') {
    const user = verifyToken(req)
    const { action, id } = req.body
    if (action === 'advance') {
      // admin action to advance status
      const ord = db.orders.find(o => o.id === id)
      if (ord) {
        if (ord.status === 'Processing') ord.status = 'Shipped'
        else if (ord.status === 'Shipped') ord.status = 'Delivered'
        writeDb(db)
      }
      return res.status(200).json({ ok: true })
    }

    // create order (mock payment succeeded)
    const { items, total } = req.body
    const order = { id: uuidv4(), items, total, status: 'Processing', createdAt: Date.now() }
    db.orders.push(order)

    // decrease stock of products
    items.forEach(it => {
      const p = db.products.find(x => x.id === it.id)
      if (p) p.stock = Math.max(0, p.stock - 1)
    })
    writeDb(db)
    return res.status(201).json({ order })
  }

  res.status(405).end()
}
