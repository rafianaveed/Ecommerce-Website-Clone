import { readDb } from '../../../utils/db'
import bcrypt from 'bcryptjs'
import { sign } from '../../../utils/auth'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { email, password } = req.body
  const db = readDb()
  const user = db.users.find(u => u.email === email)
  if (!user) return res.status(401).json({ error: 'Invalid' })
  const ok = await bcrypt.compare(password, user.password)
  if (!ok) return res.status(401).json({ error: 'Invalid' })
  const token = sign({ id: user.id, email: user.email, role: user.role })
  res.setHeader('Set-Cookie', `token=${token}; HttpOnly; Path=/; Max-Age=${60*60*24*7}`)
  res.status(200).json({ ok: true })
}
