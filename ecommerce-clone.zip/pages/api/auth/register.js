import { readDb, writeDb } from '../../../utils/db'
import bcrypt from 'bcryptjs'
import { sign } from '../../../utils/auth'
import { v4 as uuidv4 } from 'uuid'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { email, password } = req.body
  const db = readDb()
  if (db.users.find(u => u.email === email)) return res.status(400).json({ error: 'User exists' })
  const hashed = await bcrypt.hash(password, 8)
  const user = { id: uuidv4(), email, password: hashed, role: 'user' }
  db.users.push(user)
  writeDb(db)
  const token = sign({ id: user.id, email: user.email, role: user.role })
  res.setHeader('Set-Cookie', `token=${token}; HttpOnly; Path=/; Max-Age=${60*60*24*7}`)
  res.status(201).json({ ok: true })
}
