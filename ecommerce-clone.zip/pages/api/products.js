import { readDb, writeDb } from '../../utils/db'
import { verifyToken } from '../../utils/auth'
import { v4 as uuidv4 } from 'uuid'

export default function handler(req, res) {
  const db = readDb()
  if (req.method === 'GET') {
    res.status(200).json({ products: db.products })
    return
  }

  // create product (vendor/admin)
  if (req.method === 'POST') {
    const user = verifyToken(req)
    if (!user) {
      res.status(401).json({ error: 'Unauthorized' }); return
    }
    const { name, price, stock = 0, description = '' } = req.body
    const product = { id: uuidv4(), name, price, stock, description }
    db.products.push(product)
    writeDb(db)
    res.status(201).json({ product })
    return
  }

  res.status(405).end()
}
