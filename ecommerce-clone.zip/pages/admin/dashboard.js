import Layout from '../../components/Layout'
import axios from 'axios'
import { useEffect, useState } from 'react'

export default function AdminDashboard() {
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')

  useEffect(() => {
    fetchAll()
    const int = setInterval(fetchAll, 5000) // polling to show updates
    return () => clearInterval(int)
  }, [])

  async function fetchAll() {
    const p = await axios.get('/api/products')
    const o = await axios.get('/api/orders')
    setProducts(p.data.products)
    setOrders(o.data.orders)
  }

  async function addProduct(e) {
    e.preventDefault()
    await axios.post('/api/products', { name, price: Number(price), stock: 10, description: 'New product' })
    setName(''); setPrice('')
    fetchAll()
  }

  async function advanceOrder(id) {
    await axios.post('/api/orders', { action: 'advance', id })
    fetchAll()
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white p-4 border rounded">
          <h2 className="font-semibold mb-2">Create Product</h2>
          <form onSubmit={addProduct} className="space-y-2">
            <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} className="w-full p-2 border rounded" />
            <input placeholder="Price" value={price} onChange={e=>setPrice(e.target.value)} className="w-full p-2 border rounded" />
            <button className="px-3 py-1 bg-green-600 text-white rounded">Add</button>
          </form>

          <h3 className="mt-4 font-semibold">Products</h3>
          <ul className="mt-2">
            {products.map(p => <li key={p.id} className="py-1 border-b">{p.name} - ${p.price} - Stock: {p.stock}</li>)}
          </ul>
        </div>

        <div className="bg-white p-4 border rounded">
          <h2 className="font-semibold mb-2">Orders</h2>
          <ul className="space-y-2">
            {orders.map(o => (
              <li key={o.id} className="p-2 border rounded">
                <div>ID: {o.id}</div>
                <div>Status: {o.status}</div>
                <button className="mt-2 px-2 py-1 bg-blue-600 text-white rounded" onClick={()=>advanceOrder(o.id)}>Advance Status</button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Layout>
  )
}
