import axios from 'axios'
import { useEffect, useState } from 'react'
import Layout from '../components/Layout'
import ProductCard from '../components/ProductCard'
import { useDispatch } from 'react-redux'
import { addItem } from '../store/cartSlice'

export default function Home() {
  const [products, setProducts] = useState([])
  const dispatch = useDispatch()

  useEffect(() => {
    fetchProducts()
    const interval = setInterval(fetchProducts, 5000) // polling for "real-time" demo
    return () => clearInterval(interval)
  }, [])

  async function fetchProducts() {
    const res = await axios.get('/api/products')
    setProducts(res.data.products)
  }

  function handleAdd(p) {
    dispatch(addItem({ id: p.id, name: p.name, price: p.price }))
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">Products</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map(p => <ProductCard key={p.id} p={p} onAdd={handleAdd} />)}
      </div>
    </Layout>
  )
}
