import { useState } from 'react'
import axios from 'axios'
import Layout from '../components/Layout'
import Router from 'next/router'

export default function Login() {
  const [mode, setMode] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  async function submit(e) {
    e.preventDefault()
    if (mode === 'login') {
      await axios.post('/api/auth/login', { email, password })
      Router.push('/')
    } else {
      await axios.post('/api/auth/register', { email, password })
      Router.push('/')
    }
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-4">{mode === 'login' ? 'Login' : 'Register'}</h1>
      <form onSubmit={submit} className="max-w-md space-y-3 bg-white p-4 border rounded">
        <div>
          <label className="block text-sm">Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full p-2 border rounded" />
        </div>
        <div>
          <label className="block text-sm">Password</label>
          <input value={password} onChange={e=>setPassword(e.target.value)} type="password" className="w-full p-2 border rounded" />
        </div>
        <div className="flex items-center space-x-2">
          <button type="submit" className="px-3 py-1 bg-blue-600 text-white rounded">{mode==='login'?'Login':'Register'}</button>
          <button type="button" onClick={()=>setMode(mode==='login'?'register':'login')} className="underline">{mode==='login'?'Create account':'Have account? Login'}</button>
        </div>
      </form>
    </Layout>
  )
}
