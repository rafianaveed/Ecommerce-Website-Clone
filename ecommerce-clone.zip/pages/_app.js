import '../styles/globals.css'
import { Provider, useDispatch } from 'react-redux'
import store from '../store/store'
import { useEffect } from 'react'
import { loadFromLocal } from '../store/cartSlice'

function AppInner({ Component, pageProps }) {
  const dispatch = useDispatch()
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const raw = localStorage.getItem('cart')
      if (raw) dispatch(loadFromLocal(JSON.parse(raw)))
    }
  }, [dispatch])
  return <Component {...pageProps} />
}

function MyApp(props) {
  return (
    <Provider store={store}>
      <div className="min-h-screen bg-gray-50">
        <AppInner {...props} />
      </div>
    </Provider>
  )
}

export default MyApp
