import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import Layout from '../../components/Layout'
import axios from 'axios'

export default function OrderPage() {
  const router = useRouter()
  const { id } = router.query
  const [order, setOrder] = useState(null)

  useEffect(() => {
    if (!id) return
    fetchOrder()
    const int = setInterval(fetchOrder, 3000)
    return () => clearInterval(int)
  }, [id])

  async function fetchOrder() {
    const res = await axios.get('/api/orders?id=' + id)
    setOrder(res.data.order)
  }

  if (!order) return <Layout><div>Loading...</div></Layout>

  return (
    <Layout>
      <h1 className="text-2xl font-bold">Order {order.id}</h1>
      <div className="bg-white p-4 border rounded">
        <div>Status: <strong>{order.status}</strong></div>
        <div className="mt-2">Items:</div>
        <ul className="list-disc ml-6">
          {order.items.map((it, i) => <li key={i}>{it.name} - ${it.price}</li>)}
        </ul>
      </div>
    </Layout>
  )
}
