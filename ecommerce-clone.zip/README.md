# E-Commerce Platform (Mini Demo)

This is a simplified multi-vendor e-commerce demo (Next.js + React) built for learning and assignments. It implements:

- Product listing, product details
- Cart (Redux Toolkit)
- Simple register/login with JWT (stored in HttpOnly cookie)
- Admin dashboard to create products and advance order status
- Mock checkout (order created and stock updated)
- Polling-based "real-time" demo for stock and order updates

## Tech stack used
- Next.js (pages routing)
- React
- Redux Toolkit (cart)
- Tailwind CSS
- JSON file as a simple local database (data/db.json)
- JWT for auth (jsonwebtokens) and bcrypt for password hashing

## Quick start (on your PC)

1. Make sure you have **Node.js 18+** installed.

2. Unzip the project and open a terminal in the project folder:

```bash
cd ecommerce-clone
npm install
```

3. Environment variables (optional)
- You can set `JWT_SECRET` to override the default token secret.
- To integrate Stripe in production, set `STRIPE_SECRET_KEY` and update `pages/checkout.js` to call your Stripe backend. This demo uses a mock payment flow.

4. Run the dev server:

```bash
npm run dev
# open http://localhost:3000
```

5. Pre-created admin account:
- Email: `admin@example.com`
- Password: `admin123`

> Note: The admin password in the included `data/db.json` is a bcrypt hash for `admin123`. You can also register new users via the Register page.

## Files & structure (important)
- `pages/api/*` - server API routes that read/write `data/db.json` (simple local DB)
- `pages/*` - UI pages (products, cart, checkout, admin)
- `store/*` - Redux store & cart slice
- `data/db.json` - initial data (products, users, orders)

## How this satisfies assignment requirements
- Authentication & role-based access (register/login, admin checks)
- Product listing, cart, checkout (mock)
- Admin panel to manage products and orders
- Reviews can be added by extending the product object in `data/db.json`
- Real-time demo via client polling (every few seconds) — replace with WebSockets for production

## To package for production
- Replace the mock checkout with Stripe or PayPal integration.
- Replace the JSON DB with MongoDB or Firebase (update `utils/db.js` accordingly).
- Harden authentication, validate inputs, and add server-side pagination.

If you want, I can:
- Add Stripe Checkout integration (requires your Stripe test keys).
- Swap the JSON DB to MongoDB Atlas and update instructions.
- Add socket-based real-time updates (Socket.io) and show how to run.

