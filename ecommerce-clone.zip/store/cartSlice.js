import { createSlice } from '@reduxjs/toolkit'

const initial = { items: [] }

const cartSlice = createSlice({
  name: 'cart',
  initialState: initial,
  reducers: {
    addItem(state, action) {
      state.items.push(action.payload)
      if (typeof window !== 'undefined') {
        localStorage.setItem('cart', JSON.stringify(state.items))
      }
    },
    removeItem(state, action) {
      state.items = state.items.filter(i => i.id !== action.payload)
      if (typeof window !== 'undefined') {
        localStorage.setItem('cart', JSON.stringify(state.items))
      }
    },
    clearCart(state) {
      state.items = []
      if (typeof window !== 'undefined') {
        localStorage.removeItem('cart')
      }
    },
    loadFromLocal(state, action) {
      state.items = action.payload || []
    }
  }
})

export const { addItem, removeItem, clearCart, loadFromLocal } = cartSlice.actions
export default cartSlice.reducer
